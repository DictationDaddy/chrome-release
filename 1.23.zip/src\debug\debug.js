document.addEventListener('DOMContentLoaded', function () {
    // Load local storage
    chrome.storage.local.get(null, function(items) {
        document.getElementById('local-content').textContent = JSON.stringify(items, null, 2);
    });

    // Load sync storage
    chrome.storage.sync.get(null, function(items) {
        document.getElementById('sync-content').textContent = JSON.stringify(items, null, 2);
    });
});
