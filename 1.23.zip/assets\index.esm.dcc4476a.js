function Qe(e,t){return t.forEach(function(n){n&&typeof n!="string"&&!Array.isArray(n)&&Object.keys(n).forEach(function(r){if(r!=="default"&&!(r in e)){var o=Object.getOwnPropertyDescriptor(n,r);Object.defineProperty(e,r,o.get?o:{enumerable:!0,get:function(){return n[r]}})}})}),Object.freeze(Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}))}var k={exports:{}},l={};/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var x=Symbol.for("react.element"),Ze=Symbol.for("react.portal"),et=Symbol.for("react.fragment"),tt=Symbol.for("react.strict_mode"),nt=Symbol.for("react.profiler"),rt=Symbol.for("react.provider"),ot=Symbol.for("react.context"),st=Symbol.for("react.forward_ref"),it=Symbol.for("react.suspense"),at=Symbol.for("react.memo"),ct=Symbol.for("react.lazy"),fe=Symbol.iterator;function ut(e){return e===null||typeof e!="object"?null:(e=fe&&e[fe]||e["@@iterator"],typeof e=="function"?e:null)}var Te={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},Oe=Object.assign,Ne={};function N(e,t,n){this.props=e,this.context=t,this.refs=Ne,this.updater=n||Te}N.prototype.isReactComponent={};N.prototype.setState=function(e,t){if(typeof e!="object"&&typeof e!="function"&&e!=null)throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,e,t,"setState")};N.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,"forceUpdate")};function Re(){}Re.prototype=N.prototype;function oe(e,t,n){this.props=e,this.context=t,this.refs=Ne,this.updater=n||Te}var se=oe.prototype=new Re;se.constructor=oe;Oe(se,N.prototype);se.isPureReactComponent=!0;var de=Array.isArray,$e=Object.prototype.hasOwnProperty,ie={current:null},Be={key:!0,ref:!0,__self:!0,__source:!0};function Pe(e,t,n){var r,o={},s=null,i=null;if(t!=null)for(r in t.ref!==void 0&&(i=t.ref),t.key!==void 0&&(s=""+t.key),t)$e.call(t,r)&&!Be.hasOwnProperty(r)&&(o[r]=t[r]);var a=arguments.length-2;if(a===1)o.children=n;else if(1<a){for(var c=Array(a),u=0;u<a;u++)c[u]=arguments[u+2];o.children=c}if(e&&e.defaultProps)for(r in a=e.defaultProps,a)o[r]===void 0&&(o[r]=a[r]);return{$$typeof:x,type:e,key:s,ref:i,props:o,_owner:ie.current}}function lt(e,t){return{$$typeof:x,type:e.type,key:t,ref:e.ref,props:e.props,_owner:e._owner}}function ae(e){return typeof e=="object"&&e!==null&&e.$$typeof===x}function ft(e){var t={"=":"=0",":":"=2"};return"$"+e.replace(/[=:]/g,function(n){return t[n]})}var he=/\/+/g;function z(e,t){return typeof e=="object"&&e!==null&&e.key!=null?ft(""+e.key):t.toString(36)}function M(e,t,n,r,o){var s=typeof e;(s==="undefined"||s==="boolean")&&(e=null);var i=!1;if(e===null)i=!0;else switch(s){case"string":case"number":i=!0;break;case"object":switch(e.$$typeof){case x:case Ze:i=!0}}if(i)return i=e,o=o(i),e=r===""?"."+z(i,0):r,de(o)?(n="",e!=null&&(n=e.replace(he,"$&/")+"/"),M(o,t,n,"",function(u){return u})):o!=null&&(ae(o)&&(o=lt(o,n+(!o.key||i&&i.key===o.key?"":(""+o.key).replace(he,"$&/")+"/")+e)),t.push(o)),1;if(i=0,r=r===""?".":r+":",de(e))for(var a=0;a<e.length;a++){s=e[a];var c=r+z(s,a);i+=M(s,t,n,c,o)}else if(c=ut(e),typeof c=="function")for(e=c.call(e),a=0;!(s=e.next()).done;)s=s.value,c=r+z(s,a++),i+=M(s,t,n,c,o);else if(s==="object")throw t=String(e),Error("Objects are not valid as a React child (found: "+(t==="[object Object]"?"object with keys {"+Object.keys(e).join(", ")+"}":t)+"). If you meant to render a collection of children, use an array instead.");return i}function L(e,t,n){if(e==null)return e;var r=[],o=0;return M(e,r,"","",function(s){return t.call(n,s,o++)}),r}function dt(e){if(e._status===-1){var t=e._result;t=t(),t.then(function(n){(e._status===0||e._status===-1)&&(e._status=1,e._result=n)},function(n){(e._status===0||e._status===-1)&&(e._status=2,e._result=n)}),e._status===-1&&(e._status=0,e._result=t)}if(e._status===1)return e._result.default;throw e._result}var _={current:null},F={transition:null},ht={ReactCurrentDispatcher:_,ReactCurrentBatchConfig:F,ReactCurrentOwner:ie};function ke(){throw Error("act(...) is not supported in production builds of React.")}l.Children={map:L,forEach:function(e,t,n){L(e,function(){t.apply(this,arguments)},n)},count:function(e){var t=0;return L(e,function(){t++}),t},toArray:function(e){return L(e,function(t){return t})||[]},only:function(e){if(!ae(e))throw Error("React.Children.only expected to receive a single React element child.");return e}};l.Component=N;l.Fragment=et;l.Profiler=nt;l.PureComponent=oe;l.StrictMode=tt;l.Suspense=it;l.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=ht;l.act=ke;l.cloneElement=function(e,t,n){if(e==null)throw Error("React.cloneElement(...): The argument must be a React element, but you passed "+e+".");var r=Oe({},e.props),o=e.key,s=e.ref,i=e._owner;if(t!=null){if(t.ref!==void 0&&(s=t.ref,i=ie.current),t.key!==void 0&&(o=""+t.key),e.type&&e.type.defaultProps)var a=e.type.defaultProps;for(c in t)$e.call(t,c)&&!Be.hasOwnProperty(c)&&(r[c]=t[c]===void 0&&a!==void 0?a[c]:t[c])}var c=arguments.length-2;if(c===1)r.children=n;else if(1<c){a=Array(c);for(var u=0;u<c;u++)a[u]=arguments[u+2];r.children=a}return{$$typeof:x,type:e.type,key:o,ref:s,props:r,_owner:i}};l.createContext=function(e){return e={$$typeof:ot,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null,_defaultValue:null,_globalName:null},e.Provider={$$typeof:rt,_context:e},e.Consumer=e};l.createElement=Pe;l.createFactory=function(e){var t=Pe.bind(null,e);return t.type=e,t};l.createRef=function(){return{current:null}};l.forwardRef=function(e){return{$$typeof:st,render:e}};l.isValidElement=ae;l.lazy=function(e){return{$$typeof:ct,_payload:{_status:-1,_result:e},_init:dt}};l.memo=function(e,t){return{$$typeof:at,type:e,compare:t===void 0?null:t}};l.startTransition=function(e){var t=F.transition;F.transition={};try{e()}finally{F.transition=t}};l.unstable_act=ke;l.useCallback=function(e,t){return _.current.useCallback(e,t)};l.useContext=function(e){return _.current.useContext(e)};l.useDebugValue=function(){};l.useDeferredValue=function(e){return _.current.useDeferredValue(e)};l.useEffect=function(e,t){return _.current.useEffect(e,t)};l.useId=function(){return _.current.useId()};l.useImperativeHandle=function(e,t,n){return _.current.useImperativeHandle(e,t,n)};l.useInsertionEffect=function(e,t){return _.current.useInsertionEffect(e,t)};l.useLayoutEffect=function(e,t){return _.current.useLayoutEffect(e,t)};l.useMemo=function(e,t){return _.current.useMemo(e,t)};l.useReducer=function(e,t,n){return _.current.useReducer(e,t,n)};l.useRef=function(e){return _.current.useRef(e)};l.useState=function(e){return _.current.useState(e)};l.useSyncExternalStore=function(e,t,n){return _.current.useSyncExternalStore(e,t,n)};l.useTransition=function(){return _.current.useTransition()};l.version="18.3.1";k.exports=l;var xe=k.exports,Mr=Qe({__proto__:null,default:xe},[k.exports]);const pe=e=>{let t;const n=new Set,r=(y,g)=>{const b=typeof y=="function"?y(t):y;if(!Object.is(b,t)){const p=t;t=(g!=null?g:typeof b!="object"||b===null)?b:Object.assign({},t,b),n.forEach(E=>E(t,p))}},o=()=>t,c={setState:r,getState:o,getInitialState:()=>u,subscribe:y=>(n.add(y),()=>n.delete(y)),destroy:()=>{n.clear()}},u=t=e(r,o,c);return c},pt=e=>e?pe(e):pe;var Le={exports:{}},Me={},Fe={exports:{}},He={};/**
 * @license React
 * use-sync-external-store-shim.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var O=k.exports;function mt(e,t){return e===t&&(e!==0||1/e===1/t)||e!==e&&t!==t}var gt=typeof Object.is=="function"?Object.is:mt,yt=O.useState,bt=O.useEffect,Et=O.useLayoutEffect,vt=O.useDebugValue;function _t(e,t){var n=t(),r=yt({inst:{value:n,getSnapshot:t}}),o=r[0].inst,s=r[1];return Et(function(){o.value=n,o.getSnapshot=t,W(o)&&s({inst:o})},[e,n,t]),bt(function(){return W(o)&&s({inst:o}),e(function(){W(o)&&s({inst:o})})},[e]),vt(n),n}function W(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!gt(e,n)}catch{return!0}}function St(e,t){return t()}var It=typeof window=="undefined"||typeof window.document=="undefined"||typeof window.document.createElement=="undefined"?St:_t;He.useSyncExternalStore=O.useSyncExternalStore!==void 0?O.useSyncExternalStore:It;Fe.exports=He;/**
 * @license React
 * use-sync-external-store-shim/with-selector.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var V=k.exports,wt=Fe.exports;function Dt(e,t){return e===t&&(e!==0||1/e===1/t)||e!==e&&t!==t}var At=typeof Object.is=="function"?Object.is:Dt,Ct=wt.useSyncExternalStore,Tt=V.useRef,Ot=V.useEffect,Nt=V.useMemo,Rt=V.useDebugValue;Me.useSyncExternalStoreWithSelector=function(e,t,n,r,o){var s=Tt(null);if(s.current===null){var i={hasValue:!1,value:null};s.current=i}else i=s.current;s=Nt(function(){function c(p){if(!u){if(u=!0,y=p,p=r(p),o!==void 0&&i.hasValue){var E=i.value;if(o(E,p))return g=E}return g=p}if(E=g,At(y,p))return E;var h=r(p);return o!==void 0&&o(E,h)?E:(y=p,g=h)}var u=!1,y,g,b=n===void 0?null:n;return[function(){return c(t())},b===null?void 0:function(){return c(b())}]},[t,n,r,o]);var a=Ct(e,s[0],s[1]);return Ot(function(){i.hasValue=!0,i.value=a},[a]),Rt(a),a};Le.exports=Me;var $t=Le.exports;const{useDebugValue:Bt}=xe,{useSyncExternalStoreWithSelector:Pt}=$t;const kt=e=>e;function xt(e,t=kt,n){const r=Pt(e.subscribe,e.getState,e.getServerState||e.getInitialState,t,n);return Bt(r),r}const me=e=>{const t=typeof e=="function"?pt(e):e,n=(r,o)=>xt(t,r,o);return Object.assign(n,t),n},Lt=e=>e?me(e):me;var Mt=e=>Lt(e);function Ft(e,t){let n;try{n=e()}catch{return}return{getItem:o=>{var s;const i=c=>c===null?null:JSON.parse(c,t==null?void 0:t.reviver),a=(s=n.getItem(o))!=null?s:null;return a instanceof Promise?a.then(i):i(a)},setItem:(o,s)=>n.setItem(o,JSON.stringify(s,t==null?void 0:t.replacer)),removeItem:o=>n.removeItem(o)}}const $=e=>t=>{try{const n=e(t);return n instanceof Promise?n:{then(r){return $(r)(n)},catch(r){return this}}}catch(n){return{then(r){return this},catch(r){return $(r)(n)}}}},Ht=(e,t)=>(n,r,o)=>{let s={getStorage:()=>localStorage,serialize:JSON.stringify,deserialize:JSON.parse,partialize:d=>d,version:0,merge:(d,v)=>({...v,...d}),...t},i=!1;const a=new Set,c=new Set;let u;try{u=s.getStorage()}catch{}if(!u)return e((...d)=>{console.warn(`[zustand persist middleware] Unable to update item '${s.name}', the given storage is currently unavailable.`),n(...d)},r,o);const y=$(s.serialize),g=()=>{const d=s.partialize({...r()});let v;const f=y({state:d,version:s.version}).then(S=>u.setItem(s.name,S)).catch(S=>{v=S});if(v)throw v;return f},b=o.setState;o.setState=(d,v)=>{b(d,v),g()};const p=e((...d)=>{n(...d),g()},r,o);let E;const h=()=>{var d;if(!u)return;i=!1,a.forEach(f=>f(r()));const v=((d=s.onRehydrateStorage)==null?void 0:d.call(s,r()))||void 0;return $(u.getItem.bind(u))(s.name).then(f=>{if(f)return s.deserialize(f)}).then(f=>{if(f)if(typeof f.version=="number"&&f.version!==s.version){if(s.migrate)return s.migrate(f.state,f.version);console.error("State loaded from storage couldn't be migrated since no migrate function was provided")}else return f.state}).then(f=>{var S;return E=s.merge(f,(S=r())!=null?S:p),n(E,!0),g()}).then(()=>{v==null||v(E,void 0),i=!0,c.forEach(f=>f(E))}).catch(f=>{v==null||v(void 0,f)})};return o.persist={setOptions:d=>{s={...s,...d},d.getStorage&&(u=d.getStorage())},clearStorage:()=>{u==null||u.removeItem(s.name)},getOptions:()=>s,rehydrate:()=>h(),hasHydrated:()=>i,onHydrate:d=>(a.add(d),()=>{a.delete(d)}),onFinishHydration:d=>(c.add(d),()=>{c.delete(d)})},h(),E||p},Ut=(e,t)=>(n,r,o)=>{let s={storage:Ft(()=>localStorage),partialize:h=>h,version:0,merge:(h,d)=>({...d,...h}),...t},i=!1;const a=new Set,c=new Set;let u=s.storage;if(!u)return e((...h)=>{console.warn(`[zustand persist middleware] Unable to update item '${s.name}', the given storage is currently unavailable.`),n(...h)},r,o);const y=()=>{const h=s.partialize({...r()});return u.setItem(s.name,{state:h,version:s.version})},g=o.setState;o.setState=(h,d)=>{g(h,d),y()};const b=e((...h)=>{n(...h),y()},r,o);o.getInitialState=()=>b;let p;const E=()=>{var h,d;if(!u)return;i=!1,a.forEach(f=>{var S;return f((S=r())!=null?S:b)});const v=((d=s.onRehydrateStorage)==null?void 0:d.call(s,(h=r())!=null?h:b))||void 0;return $(u.getItem.bind(u))(s.name).then(f=>{if(f)if(typeof f.version=="number"&&f.version!==s.version){if(s.migrate)return s.migrate(f.state,f.version);console.error("State loaded from storage couldn't be migrated since no migrate function was provided")}else return f.state}).then(f=>{var S;return p=s.merge(f,(S=r())!=null?S:b),n(p,!0),y()}).then(()=>{v==null||v(p,void 0),p=r(),i=!0,c.forEach(f=>f(p))}).catch(f=>{v==null||v(void 0,f)})};return o.persist={setOptions:h=>{s={...s,...h},h.storage&&(u=h.storage)},clearStorage:()=>{u==null||u.removeItem(s.name)},getOptions:()=>s,rehydrate:()=>E(),hasHydrated:()=>i,onHydrate:h=>(a.add(h),()=>{a.delete(h)}),onFinishHydration:h=>(c.add(h),()=>{c.delete(h)})},s.skipHydration||E(),p||b},jt=(e,t)=>"getStorage"in t||"serialize"in t||"deserialize"in t?Ht(e,t):Ut(e,t),Vt=jt;var zt=(e=>(e.UNINITIALISED="UNINITIALISED",e.IDLE="IDLE",e.INITIALISING="INITIALISING",e.INITIALIZED="INITIALIZED",e.LISTENING="LISTENING",e.ERROR="ERROR",e.THINKING="THINKING",e))(zt||{});class Wt{async getItem(t){return new Promise(n=>{chrome.storage.local.get([t],r=>{n(r[t]!==void 0?JSON.stringify(r[t]):null)})})}async setItem(t,n){return new Promise(r=>{chrome.storage.local.set({[t]:JSON.parse(n)},r)})}async removeItem(t){return new Promise(n=>{chrome.storage.local.remove([t],n)})}}const Gt=new Wt,Fr=Mt(Vt(e=>({settings:{apiKey:"",apiSecret:"",name:"Email",model:"Ultra",language:"English",translate:!1,languageModelEnabled:!0,languageModel:"GPT-3.5 Turbo",licenseKey:"K7QbrEkzQS",checkDate:new Date,licenseValid:!0,prompt:""},knowledge:[],keywords:[],userInfo:{name:"",email:""},uid:"",setUserInfo:t=>{e({userInfo:t})},setKeywords:t=>{e({keywords:t})},setSettings:t=>{console.log("newSettings from store",t),e(n=>({settings:{...n.settings,...t}}))},setKnowledge:t=>{e({knowledge:t})},setUid:t=>{e({uid:t})}}),{name:"app-storage",getStorage:()=>Gt})),Hr=e=>{let t={};return e.forEach(n=>{t[n.key]=n.value}),t};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ue=function(e){const t=[];let n=0;for(let r=0;r<e.length;r++){let o=e.charCodeAt(r);o<128?t[n++]=o:o<2048?(t[n++]=o>>6|192,t[n++]=o&63|128):(o&64512)===55296&&r+1<e.length&&(e.charCodeAt(r+1)&64512)===56320?(o=65536+((o&1023)<<10)+(e.charCodeAt(++r)&1023),t[n++]=o>>18|240,t[n++]=o>>12&63|128,t[n++]=o>>6&63|128,t[n++]=o&63|128):(t[n++]=o>>12|224,t[n++]=o>>6&63|128,t[n++]=o&63|128)}return t},Jt=function(e){const t=[];let n=0,r=0;for(;n<e.length;){const o=e[n++];if(o<128)t[r++]=String.fromCharCode(o);else if(o>191&&o<224){const s=e[n++];t[r++]=String.fromCharCode((o&31)<<6|s&63)}else if(o>239&&o<365){const s=e[n++],i=e[n++],a=e[n++],c=((o&7)<<18|(s&63)<<12|(i&63)<<6|a&63)-65536;t[r++]=String.fromCharCode(55296+(c>>10)),t[r++]=String.fromCharCode(56320+(c&1023))}else{const s=e[n++],i=e[n++];t[r++]=String.fromCharCode((o&15)<<12|(s&63)<<6|i&63)}}return t.join("")},je={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(e,t){if(!Array.isArray(e))throw Error("encodeByteArray takes an array as a parameter");this.init_();const n=t?this.byteToCharMapWebSafe_:this.byteToCharMap_,r=[];for(let o=0;o<e.length;o+=3){const s=e[o],i=o+1<e.length,a=i?e[o+1]:0,c=o+2<e.length,u=c?e[o+2]:0,y=s>>2,g=(s&3)<<4|a>>4;let b=(a&15)<<2|u>>6,p=u&63;c||(p=64,i||(b=64)),r.push(n[y],n[g],n[b],n[p])}return r.join("")},encodeString(e,t){return this.HAS_NATIVE_SUPPORT&&!t?btoa(e):this.encodeByteArray(Ue(e),t)},decodeString(e,t){return this.HAS_NATIVE_SUPPORT&&!t?atob(e):Jt(this.decodeStringToByteArray(e,t))},decodeStringToByteArray(e,t){this.init_();const n=t?this.charToByteMapWebSafe_:this.charToByteMap_,r=[];for(let o=0;o<e.length;){const s=n[e.charAt(o++)],a=o<e.length?n[e.charAt(o)]:0;++o;const u=o<e.length?n[e.charAt(o)]:64;++o;const g=o<e.length?n[e.charAt(o)]:64;if(++o,s==null||a==null||u==null||g==null)throw new Kt;const b=s<<2|a>>4;if(r.push(b),u!==64){const p=a<<4&240|u>>2;if(r.push(p),g!==64){const E=u<<6&192|g;r.push(E)}}}return r},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let e=0;e<this.ENCODED_VALS.length;e++)this.byteToCharMap_[e]=this.ENCODED_VALS.charAt(e),this.charToByteMap_[this.byteToCharMap_[e]]=e,this.byteToCharMapWebSafe_[e]=this.ENCODED_VALS_WEBSAFE.charAt(e),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[e]]=e,e>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(e)]=e,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(e)]=e)}}};class Kt extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const qt=function(e){const t=Ue(e);return je.encodeByteArray(t,!0)},Ve=function(e){return qt(e).replace(/\./g,"")},Yt=function(e){try{return je.decodeString(e,!0)}catch(t){console.error("base64Decode failed: ",t)}return null};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Xt(){if(typeof self!="undefined")return self;if(typeof window!="undefined")return window;if(typeof global!="undefined")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Qt=()=>Xt().__FIREBASE_DEFAULTS__,Zt=()=>{if(typeof process=="undefined"||typeof process.env=="undefined")return;const e={}.__FIREBASE_DEFAULTS__;if(e)return JSON.parse(e)},en=()=>{if(typeof document=="undefined")return;let e;try{e=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const t=e&&Yt(e[1]);return t&&JSON.parse(t)},ze=()=>{try{return Qt()||Zt()||en()}catch(e){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${e}`);return}},tn=e=>{var t,n;return(n=(t=ze())===null||t===void 0?void 0:t.emulatorHosts)===null||n===void 0?void 0:n[e]},nn=e=>{const t=tn(e);if(!t)return;const n=t.lastIndexOf(":");if(n<=0||n+1===t.length)throw new Error(`Invalid host ${t} with no separate hostname and port!`);const r=parseInt(t.substring(n+1),10);return t[0]==="["?[t.substring(1,n-1),r]:[t.substring(0,n),r]},We=()=>{var e;return(e=ze())===null||e===void 0?void 0:e.config};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class rn{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((t,n)=>{this.resolve=t,this.reject=n})}wrapCallback(t){return(n,r)=>{n?this.reject(n):this.resolve(r),typeof t=="function"&&(this.promise.catch(()=>{}),t.length===1?t(n):t(n,r))}}}function on(){try{return typeof indexedDB=="object"}catch{return!1}}function sn(){return new Promise((e,t)=>{try{let n=!0;const r="validate-browser-context-for-indexeddb-analytics-module",o=self.indexedDB.open(r);o.onsuccess=()=>{o.result.close(),n||self.indexedDB.deleteDatabase(r),e(!0)},o.onupgradeneeded=()=>{n=!1},o.onerror=()=>{var s;t(((s=o.error)===null||s===void 0?void 0:s.message)||"")}}catch(n){t(n)}})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const an="FirebaseError";class R extends Error{constructor(t,n,r){super(n),this.code=t,this.customData=r,this.name=an,Object.setPrototypeOf(this,R.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,Ge.prototype.create)}}class Ge{constructor(t,n,r){this.service=t,this.serviceName=n,this.errors=r}create(t,...n){const r=n[0]||{},o=`${this.service}/${t}`,s=this.errors[t],i=s?cn(s,r):"Error",a=`${this.serviceName}: ${i} (${o}).`;return new R(o,a,r)}}function cn(e,t){return e.replace(un,(n,r)=>{const o=t[r];return o!=null?String(o):`<${r}?>`})}const un=/\{\$([^}]+)}/g;function Y(e,t){if(e===t)return!0;const n=Object.keys(e),r=Object.keys(t);for(const o of n){if(!r.includes(o))return!1;const s=e[o],i=t[o];if(ge(s)&&ge(i)){if(!Y(s,i))return!1}else if(s!==i)return!1}for(const o of r)if(!n.includes(o))return!1;return!0}function ge(e){return e!==null&&typeof e=="object"}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ce(e){return e&&e._delegate?e._delegate:e}class B{constructor(t,n,r){this.name=t,this.instanceFactory=n,this.type=r,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(t){return this.instantiationMode=t,this}setMultipleInstances(t){return this.multipleInstances=t,this}setServiceProps(t){return this.serviceProps=t,this}setInstanceCreatedCallback(t){return this.onInstanceCreated=t,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const D="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ln{constructor(t,n){this.name=t,this.container=n,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(t){const n=this.normalizeInstanceIdentifier(t);if(!this.instancesDeferred.has(n)){const r=new rn;if(this.instancesDeferred.set(n,r),this.isInitialized(n)||this.shouldAutoInitialize())try{const o=this.getOrInitializeService({instanceIdentifier:n});o&&r.resolve(o)}catch{}}return this.instancesDeferred.get(n).promise}getImmediate(t){var n;const r=this.normalizeInstanceIdentifier(t==null?void 0:t.identifier),o=(n=t==null?void 0:t.optional)!==null&&n!==void 0?n:!1;if(this.isInitialized(r)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:r})}catch(s){if(o)return null;throw s}else{if(o)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(t){if(t.name!==this.name)throw Error(`Mismatching Component ${t.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=t,!!this.shouldAutoInitialize()){if(dn(t))try{this.getOrInitializeService({instanceIdentifier:D})}catch{}for(const[n,r]of this.instancesDeferred.entries()){const o=this.normalizeInstanceIdentifier(n);try{const s=this.getOrInitializeService({instanceIdentifier:o});r.resolve(s)}catch{}}}}clearInstance(t=D){this.instancesDeferred.delete(t),this.instancesOptions.delete(t),this.instances.delete(t)}async delete(){const t=Array.from(this.instances.values());await Promise.all([...t.filter(n=>"INTERNAL"in n).map(n=>n.INTERNAL.delete()),...t.filter(n=>"_delete"in n).map(n=>n._delete())])}isComponentSet(){return this.component!=null}isInitialized(t=D){return this.instances.has(t)}getOptions(t=D){return this.instancesOptions.get(t)||{}}initialize(t={}){const{options:n={}}=t,r=this.normalizeInstanceIdentifier(t.instanceIdentifier);if(this.isInitialized(r))throw Error(`${this.name}(${r}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const o=this.getOrInitializeService({instanceIdentifier:r,options:n});for(const[s,i]of this.instancesDeferred.entries()){const a=this.normalizeInstanceIdentifier(s);r===a&&i.resolve(o)}return o}onInit(t,n){var r;const o=this.normalizeInstanceIdentifier(n),s=(r=this.onInitCallbacks.get(o))!==null&&r!==void 0?r:new Set;s.add(t),this.onInitCallbacks.set(o,s);const i=this.instances.get(o);return i&&t(i,o),()=>{s.delete(t)}}invokeOnInitCallbacks(t,n){const r=this.onInitCallbacks.get(n);if(!!r)for(const o of r)try{o(t,n)}catch{}}getOrInitializeService({instanceIdentifier:t,options:n={}}){let r=this.instances.get(t);if(!r&&this.component&&(r=this.component.instanceFactory(this.container,{instanceIdentifier:fn(t),options:n}),this.instances.set(t,r),this.instancesOptions.set(t,n),this.invokeOnInitCallbacks(r,t),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,t,r)}catch{}return r||null}normalizeInstanceIdentifier(t=D){return this.component?this.component.multipleInstances?t:D:t}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function fn(e){return e===D?void 0:e}function dn(e){return e.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hn{constructor(t){this.name=t,this.providers=new Map}addComponent(t){const n=this.getProvider(t.name);if(n.isComponentSet())throw new Error(`Component ${t.name} has already been registered with ${this.name}`);n.setComponent(t)}addOrOverwriteComponent(t){this.getProvider(t.name).isComponentSet()&&this.providers.delete(t.name),this.addComponent(t)}getProvider(t){if(this.providers.has(t))return this.providers.get(t);const n=new ln(t,this);return this.providers.set(t,n),n}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var m;(function(e){e[e.DEBUG=0]="DEBUG",e[e.VERBOSE=1]="VERBOSE",e[e.INFO=2]="INFO",e[e.WARN=3]="WARN",e[e.ERROR=4]="ERROR",e[e.SILENT=5]="SILENT"})(m||(m={}));const pn={debug:m.DEBUG,verbose:m.VERBOSE,info:m.INFO,warn:m.WARN,error:m.ERROR,silent:m.SILENT},mn=m.INFO,gn={[m.DEBUG]:"log",[m.VERBOSE]:"log",[m.INFO]:"info",[m.WARN]:"warn",[m.ERROR]:"error"},yn=(e,t,...n)=>{if(t<e.logLevel)return;const r=new Date().toISOString(),o=gn[t];if(o)console[o](`[${r}]  ${e.name}:`,...n);else throw new Error(`Attempted to log a message with an invalid logType (value: ${t})`)};class bn{constructor(t){this.name=t,this._logLevel=mn,this._logHandler=yn,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(t){if(!(t in m))throw new TypeError(`Invalid value "${t}" assigned to \`logLevel\``);this._logLevel=t}setLogLevel(t){this._logLevel=typeof t=="string"?pn[t]:t}get logHandler(){return this._logHandler}set logHandler(t){if(typeof t!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=t}get userLogHandler(){return this._userLogHandler}set userLogHandler(t){this._userLogHandler=t}debug(...t){this._userLogHandler&&this._userLogHandler(this,m.DEBUG,...t),this._logHandler(this,m.DEBUG,...t)}log(...t){this._userLogHandler&&this._userLogHandler(this,m.VERBOSE,...t),this._logHandler(this,m.VERBOSE,...t)}info(...t){this._userLogHandler&&this._userLogHandler(this,m.INFO,...t),this._logHandler(this,m.INFO,...t)}warn(...t){this._userLogHandler&&this._userLogHandler(this,m.WARN,...t),this._logHandler(this,m.WARN,...t)}error(...t){this._userLogHandler&&this._userLogHandler(this,m.ERROR,...t),this._logHandler(this,m.ERROR,...t)}}const En=(e,t)=>t.some(n=>e instanceof n);let ye,be;function vn(){return ye||(ye=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function _n(){return be||(be=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const Je=new WeakMap,X=new WeakMap,Ke=new WeakMap,G=new WeakMap,ue=new WeakMap;function Sn(e){const t=new Promise((n,r)=>{const o=()=>{e.removeEventListener("success",s),e.removeEventListener("error",i)},s=()=>{n(I(e.result)),o()},i=()=>{r(e.error),o()};e.addEventListener("success",s),e.addEventListener("error",i)});return t.then(n=>{n instanceof IDBCursor&&Je.set(n,e)}).catch(()=>{}),ue.set(t,e),t}function In(e){if(X.has(e))return;const t=new Promise((n,r)=>{const o=()=>{e.removeEventListener("complete",s),e.removeEventListener("error",i),e.removeEventListener("abort",i)},s=()=>{n(),o()},i=()=>{r(e.error||new DOMException("AbortError","AbortError")),o()};e.addEventListener("complete",s),e.addEventListener("error",i),e.addEventListener("abort",i)});X.set(e,t)}let Q={get(e,t,n){if(e instanceof IDBTransaction){if(t==="done")return X.get(e);if(t==="objectStoreNames")return e.objectStoreNames||Ke.get(e);if(t==="store")return n.objectStoreNames[1]?void 0:n.objectStore(n.objectStoreNames[0])}return I(e[t])},set(e,t,n){return e[t]=n,!0},has(e,t){return e instanceof IDBTransaction&&(t==="done"||t==="store")?!0:t in e}};function wn(e){Q=e(Q)}function Dn(e){return e===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(t,...n){const r=e.call(J(this),t,...n);return Ke.set(r,t.sort?t.sort():[t]),I(r)}:_n().includes(e)?function(...t){return e.apply(J(this),t),I(Je.get(this))}:function(...t){return I(e.apply(J(this),t))}}function An(e){return typeof e=="function"?Dn(e):(e instanceof IDBTransaction&&In(e),En(e,vn())?new Proxy(e,Q):e)}function I(e){if(e instanceof IDBRequest)return Sn(e);if(G.has(e))return G.get(e);const t=An(e);return t!==e&&(G.set(e,t),ue.set(t,e)),t}const J=e=>ue.get(e);function Cn(e,t,{blocked:n,upgrade:r,blocking:o,terminated:s}={}){const i=indexedDB.open(e,t),a=I(i);return r&&i.addEventListener("upgradeneeded",c=>{r(I(i.result),c.oldVersion,c.newVersion,I(i.transaction),c)}),n&&i.addEventListener("blocked",c=>n(c.oldVersion,c.newVersion,c)),a.then(c=>{s&&c.addEventListener("close",()=>s()),o&&c.addEventListener("versionchange",u=>o(u.oldVersion,u.newVersion,u))}).catch(()=>{}),a}const Tn=["get","getKey","getAll","getAllKeys","count"],On=["put","add","delete","clear"],K=new Map;function Ee(e,t){if(!(e instanceof IDBDatabase&&!(t in e)&&typeof t=="string"))return;if(K.get(t))return K.get(t);const n=t.replace(/FromIndex$/,""),r=t!==n,o=On.includes(n);if(!(n in(r?IDBIndex:IDBObjectStore).prototype)||!(o||Tn.includes(n)))return;const s=async function(i,...a){const c=this.transaction(i,o?"readwrite":"readonly");let u=c.store;return r&&(u=u.index(a.shift())),(await Promise.all([u[n](...a),o&&c.done]))[0]};return K.set(t,s),s}wn(e=>({...e,get:(t,n,r)=>Ee(t,n)||e.get(t,n,r),has:(t,n)=>!!Ee(t,n)||e.has(t,n)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Nn{constructor(t){this.container=t}getPlatformInfoString(){return this.container.getProviders().map(n=>{if(Rn(n)){const r=n.getImmediate();return`${r.library}/${r.version}`}else return null}).filter(n=>n).join(" ")}}function Rn(e){const t=e.getComponent();return(t==null?void 0:t.type)==="VERSION"}const Z="@firebase/app",ve="0.10.6";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const A=new bn("@firebase/app"),$n="@firebase/app-compat",Bn="@firebase/analytics-compat",Pn="@firebase/analytics",kn="@firebase/app-check-compat",xn="@firebase/app-check",Ln="@firebase/auth",Mn="@firebase/auth-compat",Fn="@firebase/database",Hn="@firebase/database-compat",Un="@firebase/functions",jn="@firebase/functions-compat",Vn="@firebase/installations",zn="@firebase/installations-compat",Wn="@firebase/messaging",Gn="@firebase/messaging-compat",Jn="@firebase/performance",Kn="@firebase/performance-compat",qn="@firebase/remote-config",Yn="@firebase/remote-config-compat",Xn="@firebase/storage",Qn="@firebase/storage-compat",Zn="@firebase/firestore",er="@firebase/vertexai-preview",tr="@firebase/firestore-compat",nr="firebase";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ee="[DEFAULT]",rr={[Z]:"fire-core",[$n]:"fire-core-compat",[Pn]:"fire-analytics",[Bn]:"fire-analytics-compat",[xn]:"fire-app-check",[kn]:"fire-app-check-compat",[Ln]:"fire-auth",[Mn]:"fire-auth-compat",[Fn]:"fire-rtdb",[Hn]:"fire-rtdb-compat",[Un]:"fire-fn",[jn]:"fire-fn-compat",[Vn]:"fire-iid",[zn]:"fire-iid-compat",[Wn]:"fire-fcm",[Gn]:"fire-fcm-compat",[Jn]:"fire-perf",[Kn]:"fire-perf-compat",[qn]:"fire-rc",[Yn]:"fire-rc-compat",[Xn]:"fire-gcs",[Qn]:"fire-gcs-compat",[Zn]:"fire-fst",[tr]:"fire-fst-compat",[er]:"fire-vertex","fire-js":"fire-js",[nr]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const H=new Map,or=new Map,te=new Map;function _e(e,t){try{e.container.addComponent(t)}catch(n){A.debug(`Component ${t.name} failed to register with FirebaseApp ${e.name}`,n)}}function U(e){const t=e.name;if(te.has(t))return A.debug(`There were multiple attempts to register component ${t}.`),!1;te.set(t,e);for(const n of H.values())_e(n,e);for(const n of or.values())_e(n,e);return!0}function sr(e,t){const n=e.container.getProvider("heartbeat").getImmediate({optional:!0});return n&&n.triggerHeartbeat(),e.container.getProvider(t)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ir={["no-app"]:"No Firebase App '{$appName}' has been created - call initializeApp() first",["bad-app-name"]:"Illegal App name: '{$appName}'",["duplicate-app"]:"Firebase App named '{$appName}' already exists with different options or config",["app-deleted"]:"Firebase App named '{$appName}' already deleted",["server-app-deleted"]:"Firebase Server App has been deleted",["no-options"]:"Need to provide options, when not being deployed to hosting via source.",["invalid-app-argument"]:"firebase.{$appName}() takes either no argument or a Firebase App instance.",["invalid-log-argument"]:"First argument to `onLog` must be null or a function.",["idb-open"]:"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.",["idb-get"]:"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.",["idb-set"]:"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.",["idb-delete"]:"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.",["finalization-registry-not-supported"]:"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.",["invalid-server-app-environment"]:"FirebaseServerApp is not for use in browser environments."},w=new Ge("app","Firebase",ir);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ar{constructor(t,n,r){this._isDeleted=!1,this._options=Object.assign({},t),this._config=Object.assign({},n),this._name=n.name,this._automaticDataCollectionEnabled=n.automaticDataCollectionEnabled,this._container=r,this.container.addComponent(new B("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(t){this.checkDestroyed(),this._automaticDataCollectionEnabled=t}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(t){this._isDeleted=t}checkDestroyed(){if(this.isDeleted)throw w.create("app-deleted",{appName:this._name})}}function cr(e,t={}){let n=e;typeof t!="object"&&(t={name:t});const r=Object.assign({name:ee,automaticDataCollectionEnabled:!1},t),o=r.name;if(typeof o!="string"||!o)throw w.create("bad-app-name",{appName:String(o)});if(n||(n=We()),!n)throw w.create("no-options");const s=H.get(o);if(s){if(Y(n,s.options)&&Y(r,s.config))return s;throw w.create("duplicate-app",{appName:o})}const i=new hn(o);for(const c of te.values())i.addComponent(c);const a=new ar(n,r,i);return H.set(o,a),a}function ur(e=ee){const t=H.get(e);if(!t&&e===ee&&We())return cr();if(!t)throw w.create("no-app",{appName:e});return t}function C(e,t,n){var r;let o=(r=rr[e])!==null&&r!==void 0?r:e;n&&(o+=`-${n}`);const s=o.match(/\s|\//),i=t.match(/\s|\//);if(s||i){const a=[`Unable to register library "${o}" with version "${t}":`];s&&a.push(`library name "${o}" contains illegal characters (whitespace or "/")`),s&&i&&a.push("and"),i&&a.push(`version name "${t}" contains illegal characters (whitespace or "/")`),A.warn(a.join(" "));return}U(new B(`${o}-version`,()=>({library:o,version:t}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const lr="firebase-heartbeat-database",fr=1,P="firebase-heartbeat-store";let q=null;function qe(){return q||(q=Cn(lr,fr,{upgrade:(e,t)=>{switch(t){case 0:try{e.createObjectStore(P)}catch(n){console.warn(n)}}}}).catch(e=>{throw w.create("idb-open",{originalErrorMessage:e.message})})),q}async function dr(e){try{const n=(await qe()).transaction(P),r=await n.objectStore(P).get(Ye(e));return await n.done,r}catch(t){if(t instanceof R)A.warn(t.message);else{const n=w.create("idb-get",{originalErrorMessage:t==null?void 0:t.message});A.warn(n.message)}}}async function Se(e,t){try{const r=(await qe()).transaction(P,"readwrite");await r.objectStore(P).put(t,Ye(e)),await r.done}catch(n){if(n instanceof R)A.warn(n.message);else{const r=w.create("idb-set",{originalErrorMessage:n==null?void 0:n.message});A.warn(r.message)}}}function Ye(e){return`${e.name}!${e.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const hr=1024,pr=30*24*60*60*1e3;class mr{constructor(t){this.container=t,this._heartbeatsCache=null;const n=this.container.getProvider("app").getImmediate();this._storage=new yr(n),this._heartbeatsCachePromise=this._storage.read().then(r=>(this._heartbeatsCache=r,r))}async triggerHeartbeat(){var t,n;const o=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),s=Ie();if(!(((t=this._heartbeatsCache)===null||t===void 0?void 0:t.heartbeats)==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,((n=this._heartbeatsCache)===null||n===void 0?void 0:n.heartbeats)==null))&&!(this._heartbeatsCache.lastSentHeartbeatDate===s||this._heartbeatsCache.heartbeats.some(i=>i.date===s)))return this._heartbeatsCache.heartbeats.push({date:s,agent:o}),this._heartbeatsCache.heartbeats=this._heartbeatsCache.heartbeats.filter(i=>{const a=new Date(i.date).valueOf();return Date.now()-a<=pr}),this._storage.overwrite(this._heartbeatsCache)}async getHeartbeatsHeader(){var t;if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,((t=this._heartbeatsCache)===null||t===void 0?void 0:t.heartbeats)==null||this._heartbeatsCache.heartbeats.length===0)return"";const n=Ie(),{heartbeatsToSend:r,unsentEntries:o}=gr(this._heartbeatsCache.heartbeats),s=Ve(JSON.stringify({version:2,heartbeats:r}));return this._heartbeatsCache.lastSentHeartbeatDate=n,o.length>0?(this._heartbeatsCache.heartbeats=o,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),s}}function Ie(){return new Date().toISOString().substring(0,10)}function gr(e,t=hr){const n=[];let r=e.slice();for(const o of e){const s=n.find(i=>i.agent===o.agent);if(s){if(s.dates.push(o.date),we(n)>t){s.dates.pop();break}}else if(n.push({agent:o.agent,dates:[o.date]}),we(n)>t){n.pop();break}r=r.slice(1)}return{heartbeatsToSend:n,unsentEntries:r}}class yr{constructor(t){this.app=t,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return on()?sn().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const n=await dr(this.app);return n!=null&&n.heartbeats?n:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(t){var n;if(await this._canUseIndexedDBPromise){const o=await this.read();return Se(this.app,{lastSentHeartbeatDate:(n=t.lastSentHeartbeatDate)!==null&&n!==void 0?n:o.lastSentHeartbeatDate,heartbeats:t.heartbeats})}else return}async add(t){var n;if(await this._canUseIndexedDBPromise){const o=await this.read();return Se(this.app,{lastSentHeartbeatDate:(n=t.lastSentHeartbeatDate)!==null&&n!==void 0?n:o.lastSentHeartbeatDate,heartbeats:[...o.heartbeats,...t.heartbeats]})}else return}}function we(e){return Ve(JSON.stringify({version:2,heartbeats:e})).length}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function br(e){U(new B("platform-logger",t=>new Nn(t),"PRIVATE")),U(new B("heartbeat",t=>new mr(t),"PRIVATE")),C(Z,ve,e),C(Z,ve,"esm2017"),C("fire-js","")}br("");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Er="type.googleapis.com/google.protobuf.Int64Value",vr="type.googleapis.com/google.protobuf.UInt64Value";function Xe(e,t){const n={};for(const r in e)e.hasOwnProperty(r)&&(n[r]=t(e[r]));return n}function ne(e){if(e==null)return null;if(e instanceof Number&&(e=e.valueOf()),typeof e=="number"&&isFinite(e)||e===!0||e===!1||Object.prototype.toString.call(e)==="[object String]")return e;if(e instanceof Date)return e.toISOString();if(Array.isArray(e))return e.map(t=>ne(t));if(typeof e=="function"||typeof e=="object")return Xe(e,t=>ne(t));throw new Error("Data cannot be encoded in JSON: "+e)}function j(e){if(e==null)return e;if(e["@type"])switch(e["@type"]){case Er:case vr:{const t=Number(e.value);if(isNaN(t))throw new Error("Data cannot be decoded from JSON: "+e);return t}default:throw new Error("Data cannot be decoded from JSON: "+e)}return Array.isArray(e)?e.map(t=>j(t)):typeof e=="function"||typeof e=="object"?Xe(e,t=>j(t)):e}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const le="functions";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const De={OK:"ok",CANCELLED:"cancelled",UNKNOWN:"unknown",INVALID_ARGUMENT:"invalid-argument",DEADLINE_EXCEEDED:"deadline-exceeded",NOT_FOUND:"not-found",ALREADY_EXISTS:"already-exists",PERMISSION_DENIED:"permission-denied",UNAUTHENTICATED:"unauthenticated",RESOURCE_EXHAUSTED:"resource-exhausted",FAILED_PRECONDITION:"failed-precondition",ABORTED:"aborted",OUT_OF_RANGE:"out-of-range",UNIMPLEMENTED:"unimplemented",INTERNAL:"internal",UNAVAILABLE:"unavailable",DATA_LOSS:"data-loss"};class T extends R{constructor(t,n,r){super(`${le}/${t}`,n||""),this.details=r}}function _r(e){if(e>=200&&e<300)return"ok";switch(e){case 0:return"internal";case 400:return"invalid-argument";case 401:return"unauthenticated";case 403:return"permission-denied";case 404:return"not-found";case 409:return"aborted";case 429:return"resource-exhausted";case 499:return"cancelled";case 500:return"internal";case 501:return"unimplemented";case 503:return"unavailable";case 504:return"deadline-exceeded"}return"unknown"}function Sr(e,t){let n=_r(e),r=n,o;try{const s=t&&t.error;if(s){const i=s.status;if(typeof i=="string"){if(!De[i])return new T("internal","internal");n=De[i],r=i}const a=s.message;typeof a=="string"&&(r=a),o=s.details,o!==void 0&&(o=j(o))}}catch{}return n==="ok"?null:new T(n,r,o)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ir{constructor(t,n,r){this.auth=null,this.messaging=null,this.appCheck=null,this.auth=t.getImmediate({optional:!0}),this.messaging=n.getImmediate({optional:!0}),this.auth||t.get().then(o=>this.auth=o,()=>{}),this.messaging||n.get().then(o=>this.messaging=o,()=>{}),this.appCheck||r.get().then(o=>this.appCheck=o,()=>{})}async getAuthToken(){if(!!this.auth)try{const t=await this.auth.getToken();return t==null?void 0:t.accessToken}catch{return}}async getMessagingToken(){if(!(!this.messaging||!("Notification"in self)||Notification.permission!=="granted"))try{return await this.messaging.getToken()}catch{return}}async getAppCheckToken(t){if(this.appCheck){const n=t?await this.appCheck.getLimitedUseToken():await this.appCheck.getToken();return n.error?null:n.token}return null}async getContext(t){const n=await this.getAuthToken(),r=await this.getMessagingToken(),o=await this.getAppCheckToken(t);return{authToken:n,messagingToken:r,appCheckToken:o}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const re="us-central1";function wr(e){let t=null;return{promise:new Promise((n,r)=>{t=setTimeout(()=>{r(new T("deadline-exceeded","deadline-exceeded"))},e)}),cancel:()=>{t&&clearTimeout(t)}}}class Dr{constructor(t,n,r,o,s=re,i){this.app=t,this.fetchImpl=i,this.emulatorOrigin=null,this.contextProvider=new Ir(n,r,o),this.cancelAllRequests=new Promise(a=>{this.deleteService=()=>Promise.resolve(a())});try{const a=new URL(s);this.customDomain=a.origin,this.region=re}catch{this.customDomain=null,this.region=s}}_delete(){return this.deleteService()}_url(t){const n=this.app.options.projectId;return this.emulatorOrigin!==null?`${this.emulatorOrigin}/${n}/${this.region}/${t}`:this.customDomain!==null?`${this.customDomain}/${t}`:`https://${this.region}-${n}.cloudfunctions.net/${t}`}}function Ar(e,t,n){e.emulatorOrigin=`http://${t}:${n}`}function Cr(e,t,n){return r=>Or(e,t,r,n||{})}async function Tr(e,t,n,r){n["Content-Type"]="application/json";let o;try{o=await r(e,{method:"POST",body:JSON.stringify(t),headers:n})}catch{return{status:0,json:null}}let s=null;try{s=await o.json()}catch{}return{status:o.status,json:s}}function Or(e,t,n,r){const o=e._url(t);return Nr(e,o,n,r)}async function Nr(e,t,n,r){n=ne(n);const o={data:n},s={},i=await e.contextProvider.getContext(r.limitedUseAppCheckTokens);i.authToken&&(s.Authorization="Bearer "+i.authToken),i.messagingToken&&(s["Firebase-Instance-ID-Token"]=i.messagingToken),i.appCheckToken!==null&&(s["X-Firebase-AppCheck"]=i.appCheckToken);const a=r.timeout||7e4,c=wr(a),u=await Promise.race([Tr(t,o,s,e.fetchImpl),c.promise,e.cancelAllRequests]);if(c.cancel(),!u)throw new T("cancelled","Firebase Functions instance was deleted.");const y=Sr(u.status,u.json);if(y)throw y;if(!u.json)throw new T("internal","Response is not valid JSON object.");let g=u.json.data;if(typeof g=="undefined"&&(g=u.json.result),typeof g=="undefined")throw new T("internal","Response is missing data field.");return{data:j(g)}}const Ae="@firebase/functions",Ce="0.11.6";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Rr="auth-internal",$r="app-check-internal",Br="messaging-internal";function Pr(e,t){const n=(r,{instanceIdentifier:o})=>{const s=r.getProvider("app").getImmediate(),i=r.getProvider(Rr),a=r.getProvider(Br),c=r.getProvider($r);return new Dr(s,i,a,c,o,e)};U(new B(le,n,"PUBLIC").setMultipleInstances(!0)),C(Ae,Ce,t),C(Ae,Ce,"esm2017")}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ur(e=ur(),t=re){const r=sr(ce(e),le).getImmediate({identifier:t}),o=nn("functions");return o&&kr(r,...o),r}function kr(e,t,n){Ar(ce(e),t,n)}function jr(e,t,n){return Cr(ce(e),t,n)}Pr(fetch.bind(self));var xr="firebase",Lr="10.12.3";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */C(xr,Lr,"app");export{zt as M,xe as R,Mr as a,Hr as c,Ur as g,jr as h,cr as i,k as r,Fr as u};
