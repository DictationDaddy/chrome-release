// This URL must point to the public site
const _URL = 'https://auth-dictationdaddy.web.app/';
console.log('Offscreen document initialized with URL:', _URL);

const iframe = document.createElement('iframe');
iframe.src = _URL;
document.documentElement.appendChild(iframe);
console.log('Iframe created and appended to document');

chrome.runtime.onMessage.addListener(handleChromeMessages);
console.log('Chrome message listener added');

function handleChromeMessages(message, sender, sendResponse) {
  console.log('Received chrome message:', message);

  // Extensions may have a number of other reasons to send messages, so you
  // should filter out any that are not meant for the offscreen document.
  if (message.target !== 'offscreen') {
    console.log('Message not intended for offscreen document, ignoring');
    return false;
  }

  function handleIframeMessage({data}) {
    console.log('Received iframe message:', data);
    try {
      if (data.startsWith('!_{')) {
        // Other parts of the Firebase library send messages using postMessage.
        // You don't care about them in this context, so return early.
        console.log('Ignoring Firebase internal message');
        return;
      }
      data = JSON.parse(data);
      console.log('Parsed iframe message data:', data);
      self.removeEventListener('message', handleIframeMessage);
      console.log('Removed iframe message listener');

      sendResponse(data);
      console.log('Sent response back to chrome runtime');
    } catch (e) {
      console.error('JSON parse failed:', e.message);
    }
  }

  globalThis.addEventListener('message', handleIframeMessage, false);
  console.log('Added iframe message listener');

  // Initialize the authentication flow in the iframed document. You must set the
  // second argument (targetOrigin) of the message in order for it to be successfully
  // delivered.
  const targetOrigin = new URL(_URL).origin;
  console.log('Posting initAuth message to iframe with target origin:', targetOrigin);
  iframe.contentWindow.postMessage({"initAuth": true}, targetOrigin);
  
  return true;
}

console.log('Offscreen document setup complete');